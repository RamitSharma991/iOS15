import UIKit
//
//let names = ["Sterling", "Cyril", "Lana", "Ray", "Pam"]
//
//for _ in names {
//    print("x is a secret agent!")
//}
//
//
//var averageScore = 2.5
//while averageScore < 15.0 {
//    averageScore += 2.5
//    print("The average score is \(averageScore)")
//}
//
//
//var speed = 50
//while speed <= 55 {
//    print("Accelerating to \(speed)")
//    speed += 1
//}
//
//var bagels = 5
//repeat {
//    print("Someone ate a bagel!")
//    bagels -= 1
//} while bagels > 0
//
//
//var scales = ["A", "B", "C", "D", "E"]
//var scaleCounter = 0
//repeat {
//    print("Play the \(scales[scaleCounter]) scale")
//    scaleCounter += 1
//} while scaleCounter < 3
//
//
//for i in 1...15 {
//    let square = i * i
//    if i == 8 {
//        continue
//    }
//    print("\(i) squared is \(square)")
//}
//
//var counting = 0
//while counting <= 20 {
//    counting += 1
//    if counting > 5 {
//
//        continue
//    }
//    print("\(counting)...")
//}
//print("Ready or not, here I come!")
//
//
//var distanceFlown = 0
//while true {
//    distanceFlown += 100
//    if distanceFlown == 500 {
//        continue
//    }
//    print(distanceFlown)
//    if distanceFlown == 1000 {
//        break
//    }
//}
//for i in 1...100 {
//    if 100 % i == 0 {
//        print("100 divides evenly into \(i)")
//    } else {
//        continue
//    }
//}
//
//for i in 1...5 {
//    if i == 5 {
//        continue
//    }
//    let sum = i + i
//    print("\(i) + \(i) is \(sum).")
//}

//var isVisible = true
//while isVisible == true {
//    isVisible = false
//    if isVisible == false {
//        isVisible = true
//    }
//}
//
//func countMultiplesOf10(numbers: [Int]) -> Int {
//    var result = 0
//    for number in numbers {
//        if number % 10 == 0 {
//            result += 1
//        }
//    }
//    return result
//}
//countMultiplesOf10(numbers: [5, 10, 15, 20, 25])
//
//func countDown(from start: Int) {
//    var current = start
//    while current >= 0 {
//        print("\(current)...")
//        current -= 1
//    }
//}
//countDown(from: 10)
//
//
//func isEveryoneCanadian(_ birthCountries: [String]) {
//    for country in birthCountries {
//        if country != "Canada" {
//            return false
//        }
//    }
//    return true
//}
//


struct GalacticaCrew {
    var isCylon = false
}
var starbuck = GalacticaCrew()
var tyrol = starbuck
tyrol.isCylon = true
print(starbuck.isCylon)
print(tyrol.isCylon)



struct Calculator {
    var currentTotal = 0
}
var baseModel = Calculator()
var casio = baseModel
var texas = baseModel
casio.currentTotal = 556
texas.currentTotal = 384
print(casio.currentTotal)
print(texas.currentTotal)


class Statue {
    var sculptor = "Unknown"
}
var venusDeMilo = Statue()
venusDeMilo.sculptor = "Alexandros of Antioch"

var david = Statue()
david.sculptor = "Michaelangelo"

print(venusDeMilo.sculptor)
print(david.sculptor)


class Starship {
    var maxWarp = 9.0
}
var voyager = Starship()
voyager.maxWarp = 9.975

var enterprise = voyager
enterprise.maxWarp = 9.6

print(voyager.maxWarp)
print(enterprise.maxWarp)




class Hospital {
    var onCallStaff = [String]()
}
var londonCentral = Hospital()
var londonWest = londonCentral
londonCentral.onCallStaff.append("Dr Harlan")
londonWest.onCallStaff.append("Dr Haskins")
print(londonCentral.onCallStaff.count)
print(londonWest.onCallStaff.count)


class Magazine {
    var pageCount = 132
}
var example = Magazine()
var wired = example
wired.pageCount = 164

var vogue = example
vogue.pageCount = 128

print(wired.pageCount)
print(vogue.pageCount)

